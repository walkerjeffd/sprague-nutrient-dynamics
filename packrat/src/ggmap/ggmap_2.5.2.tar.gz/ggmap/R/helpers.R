`%notin%` <- function(elem, set){
  !(elem %in% set)
}
