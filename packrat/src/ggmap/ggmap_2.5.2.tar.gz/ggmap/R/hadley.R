#' Highly unofficial ggplot2 image
#'
#' @name hadley
#' @docType data
#' @author Garrett Grolemund \email{grolemund@@gmail.com}
NULL