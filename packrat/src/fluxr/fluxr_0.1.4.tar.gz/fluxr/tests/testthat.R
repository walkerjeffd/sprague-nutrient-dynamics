library(testthat)
library(fluxr)

test_check("fluxr")
