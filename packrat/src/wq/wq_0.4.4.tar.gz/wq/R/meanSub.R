meanSub <- function(x, sub, na.rm = FALSE) {
    mean(x[sub], na.rm = na.rm)
}
