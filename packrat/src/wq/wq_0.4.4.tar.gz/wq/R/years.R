years <-
  function(y) as.numeric(format(y, "%Y"))