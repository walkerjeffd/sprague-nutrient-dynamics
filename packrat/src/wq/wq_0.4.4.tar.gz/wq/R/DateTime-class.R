setClassUnion("DateTime", c("Date", "POSIXct"))
